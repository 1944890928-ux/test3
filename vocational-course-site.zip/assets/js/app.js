(function(){
  window.openCourse = function(id){ alert('示范：进入课程 ' + id) }
  window.enroll = function(id){ alert('已为您选修：' + id) }
  window.openMaterialFolder = function(){ window.location.href = 'materials/' }
  window.postDiscussion = function(){
    const content = document.getElementById('postContent').value.trim()
    if(!content){alert('请输入内容');return}
    const board = document.getElementById('discussBoard')
    const div = document.createElement('div')
    div.className = 'post'
    div.innerHTML = '<h5>学生 · 提问</h5><p>' + escapeHtml(content) + '</p>'
    board.insertBefore(div, board.firstChild)
    document.getElementById('postContent').value = ''
  }
  window.escapeHtml = function(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
  document.getElementById('loginBtn').addEventListener('click',function(){ alert('示范登录弹窗') })
})();